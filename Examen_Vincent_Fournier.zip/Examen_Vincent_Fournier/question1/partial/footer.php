</div>
		</div>
		<div class="center">
            <form action="" method="get">
                <input type="hidden" name="noMore" id="chickens" value="0">
                <button>Vider</button>
            </form>
		</div>
	</body>
</html>