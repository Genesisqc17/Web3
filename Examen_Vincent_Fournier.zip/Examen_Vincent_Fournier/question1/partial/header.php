<!DOCTYPE html>
<html>
	<head>
		<title>La basse-cour</title>
		<link rel="stylesheet" href="css/global.css">
		<meta charset="utf-8" />
	</head>
	<body>
		<h1>Bienvenue à la basse-cour</h1>
		<div class="frame">
			<div id="container">
                