<?php
    define("DB_DRIVER", "mysql");
    define("DB_HOST", "webpgsql.notes-de-cours.com:13306");
    define("DB_USER", "exam_user");
    define("DB_DATABASE", "exam_db");
    define("DB_PASS", "theyarewatchingyouneo");